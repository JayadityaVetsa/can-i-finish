# Can I Finish?

**Keyboard journeys, with evidence you can rerun.**

Define a concrete task, send keyboard input through a real browser, inspect where it stops, and run the same contract after a fix. Built for Next Byte Hacks V5 on November 1, 2026. The entry stays a draft until the user explicitly requests submission.

## What is working

- Local Node.js + Playwright runner with real Chromium keyboard input.
- Explicit task contracts: Tab to an accessible role/name, press keys, assert visible or hidden task states.
- A screenshot and focus record after each input, with a SHA-256 content hash.
- Native browser recording, focus trace, reproduction report, contract export, and generated regression script.
- Hosted/static evidence viewer with screenshot-backed playback, focus inspector, and before/after comparison.
- Two controlled journeys in broken and fixed variants: reach course registration; dismiss an updates dialog and continue registration.
- Local UI can rerun those fixtures or run a supplied contract against a public URL. No authentication automation or personal form filling.

## Run for free

Requires Node.js 20+. Chromium downloads once; no API key or paid service.

```sh
npm ci
npx playwright install chromium
npm start
# Open http://127.0.0.1:4174
```

The entry point uses the project-local `.local/browsers` cache when present, otherwise Playwright's normal cache. Set PLAYWRIGHT_BROWSERS_PATH explicitly to override it.

In the local workspace, choose **New browser run**. Choose a fixture, or a public URL and a JSON contract. The hosted site is a recorded evidence viewer; it does not pretend to launch a cloud browser.

```sh
npm run demo       # Executes all four fixture journeys; regenerates dist/evidence/
npm test           # Verifies outcomes, matching contracts, artifact integrity and input validation
node cli.mjs run https://your-test-site.example contract.json
```

The CLI accepts URLs you supply; run against a site you are authorized to test. Contracts can activate controls with Enter or Space. Use test copies of transactional workflows. The local HTTP service binds only to loopback and requires same-origin JSON requests; its custom-URL entry rejects obvious private-network initial URLs. It is not intended as a public remote-browser service.

## How it works

`lib/contracts.mjs` defines the tasks; `lib/runner.mjs` executes them. The runner starts a fresh context, navigates, and uses `page.keyboard.press`. It does not call `click` or `locator.focus()` to reach a target. Page evaluation is read-only observation of focus/CSS/DOM. Target matching uses Playwright's accessible role and name lookup. Focus labels in trace metadata are approximate.

On each key, it captures a PNG, focus metadata, timestamp, and hash. Native video comes from Playwright's context recording. An assertion failure stops the task. A failed dialog-dismiss assertion adds a small explicitly labelled diagnostic probe. The report does not automatically label normal modal focus containment a WCAG violation.

`dist/app.js` renders saved evidence, can import/export report JSON, and connects to `/api/run` only on the local workspace. Static hosting needs no backend. Imported JSON cannot inject HTML or reference arbitrary external screenshot URLs. JSON import alone does not transport its screenshot files; serve the associated evidence folder to retain images.

`npm run demo` produces actual runs. Viewer outcomes and metrics come from those reports, not hardcoded pass/fail states. Both fixture variants share an identical contract. Fixtures intentionally contain the bugs; this is a demonstration, not independent validation on production sites.

## Observed demo results

| Journey | Before | After |
| --- | --- | --- |
| Reach registration | Target not reached after 18 Tab presses; rendered div button has tabIndex -1 | Completed in 5 key events |
| Dismiss dialog and continue | Dialog visible after Escape; diagnostic Tab/Shift+Tab stays on two controls | Completed in 7 key events |

Observed with Playwright 1.64.1 and Chromium 156.0.8078.4 on Windows, viewport 1280×900. Generated reports contain exact capture times and browser versions. Counts reflect these fixtures only.

## Scope and limitations

This is one browser/viewport/keyboard-sequence test, not a full accessibility audit, legal compliance determination, or WCAG certification. A bounded Tab failure can require another documented keyboard sequence. The tool records focus-indicator metadata and screenshots; it does not automatically judge visual contrast. Screen readers, cross-origin frames, complex shadow DOM workflows, mobile, authentication, automatic code repair and natural-language task planning are not validated features.

Screenshots and videos can contain page content. Local runs remain under `reports/`; only controlled demo captures are included in the hosted app. Never publish a private report without reviewing it. Hashes establish content integrity within the bundle, not external trust or third-party certification.

## Differentiation and prior art

Keyboard testing already exists in axe DevTools and open-source Playwright tools. This prototype focuses on task outcome contracts, a small inspectable evidence package, generated keyboard regressions, and matched before/after runs. It does not claim to invent keyboard testing or outperform those tools. Real-user studies and independent evaluation remain future work.

Sources: https://www.deque.com/blog/intelligent-automation-and-the-new-era-of-guided-testing/ ; https://github.com/stevefaulkner/keyboard-vibes ; https://playwright.dev/docs/api/class-keyboard ; https://www.w3.org/WAI/WCAG22/Understanding/no-keyboard-trap.html

## AI and licensing

Codex assisted in architecture, code, fixtures, tests, interface, and documentation. The running product does not use a language model. Playwright is Apache-2.0 licensed; Chromium and bundled tooling retain their respective licenses. Original project code is MIT licensed. No user interviews, production adoption, or measured user-impact claims are fabricated.
